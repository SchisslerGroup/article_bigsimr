library(testthat)
library(bigsimr)

test_check("bigsimr")
