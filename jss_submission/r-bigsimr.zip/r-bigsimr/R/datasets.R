#' BRCA dataset
#'
#' 200 of the highest expressing genes from the BRCA data set.
"brca"
